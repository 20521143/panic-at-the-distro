Reference
=========

.. automodule:: smartypants
   :members:
   :private-members:
