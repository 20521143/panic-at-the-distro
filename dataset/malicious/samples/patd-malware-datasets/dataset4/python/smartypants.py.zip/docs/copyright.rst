.. include:: ../COPYING
