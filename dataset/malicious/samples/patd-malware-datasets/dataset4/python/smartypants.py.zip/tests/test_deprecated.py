#!/usr/bin/env python
# Copyright (c) 2017 Leo Hemsted
# Licensed under the BSD License, for detailed license information, see COPYING

import unittest


class SmartyPantsDeprecatedTestCase(unittest.TestCase):

    pass
