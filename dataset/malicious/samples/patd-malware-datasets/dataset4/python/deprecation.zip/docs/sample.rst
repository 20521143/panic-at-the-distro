:orphan:

``sample`` module
=================

The following documents the ``sample`` module to show what documentation
looks like when :func:`~deprecation.deprecated` has modified it.

.. automodule:: sample
   :members:
