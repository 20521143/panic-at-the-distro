license\_expression package
===========================

Module contents
---------------

.. automodule:: license_expression
   :members:
   :undoc-members:
   :show-inheritance:
