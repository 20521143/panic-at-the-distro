module Fluent
  module Plugin
    module Cloudwatch
      module Logs
        VERSION = "0.14.3"
      end
    end
  end
end
