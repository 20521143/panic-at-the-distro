require "fluent/plugin/cloudwatch/logs/version"

module Fluent
  module Plugin
    module Cloudwatch
      module Logs
        # Your code goes here...
      end
    end
  end
end
