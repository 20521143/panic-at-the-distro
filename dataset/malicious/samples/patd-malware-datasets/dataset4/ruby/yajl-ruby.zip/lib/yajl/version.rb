module Yajl
  VERSION = '1.4.3'
end
