module LambdaCalculus
  class Application < Treetop::Runtime::SyntaxNode
    
  end
end