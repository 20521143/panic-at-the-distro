module Oj
  # Current version of the module.
  VERSION = '3.16.4'
end
