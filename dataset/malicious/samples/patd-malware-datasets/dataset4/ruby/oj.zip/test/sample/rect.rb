module Sample
  class Rect < Shape

    def initialize(left, top, wide, high, color=nil)
      super
    end

  end # Rect
end # Sample
