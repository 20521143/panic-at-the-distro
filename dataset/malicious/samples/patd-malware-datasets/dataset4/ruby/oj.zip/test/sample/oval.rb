module Sample

  class Oval < Shape

    def initialize(left, top, wide, high, color=nil)
      super
    end

  end # Oval
end # Sample
