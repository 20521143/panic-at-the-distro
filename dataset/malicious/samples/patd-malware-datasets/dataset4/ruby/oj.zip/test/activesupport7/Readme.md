Tests copied from [rails/activesupport/test/json/],
[rails/activesupport/lib/active_support], [rails/activesupport/test].

[rails/activesupport/test/json/]: https://github.com/rails/rails/tree/v7.0.3/activesupport/test/json
[rails/activesupport/lib/active_support]: https://github.com/rails/rails/tree/v7.0.3/activesupport/lib/active_support
[rails/activesupport/test]: https://github.com/rails/rails/tree/v7.0.3/activesupport/test
