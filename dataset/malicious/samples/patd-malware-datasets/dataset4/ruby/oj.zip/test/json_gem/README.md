# Original JSON tests

Ported from [ruby/test/json](https://github.com/ruby/ruby/tree/trunk/test/json).

Omitted - tests which Oj will not support.
