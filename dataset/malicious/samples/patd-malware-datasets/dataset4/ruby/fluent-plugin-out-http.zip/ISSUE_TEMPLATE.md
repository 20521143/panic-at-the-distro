#### Problem

...

#### Steps to replicate

Provide example config and message

#### Expected Behavior or What you need to ask

...

#### Using Fluentd and out_http plugin versions

* OS version
* Fluentd v0.12 or v0.14/v1.0
  * paste result of ``fluentd --version`` or ``td-agent --version``
* out_http plugin 1.x.y or 0.x.y
  * paste boot log of fluentd or td-agent
  * paste result of ``fluent-gem list``, ``td-agent-gem list`` or your Gemfile.lock
* Bear Metal or Within Docker or Kubernetes or others? (optional)
