module ServerEngine
  VERSION = "2.3.2"
end
