**What should the new rule do?**

**What new ECMAScript feature does this rule relate to? Note that we only accept new core rules related to new ECMAScript features.**

**What category of rule is this (place an "X" next to just one item)?**

[ ] Warns about a potential problem
[ ] Suggests an alternate way of doing something

**Please provide some example JavaScript code that this rule will warn about:**

```js
<!-- put your code examples here -->
```

**Why should this rule be included in ESLint (instead of a plugin)?**
