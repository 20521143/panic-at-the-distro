**What rule do you want to change?**

**What change do you want to make (place an "X" next to just one item)?**

[ ] Generate more warnings
[ ] Generate fewer warnings
[ ] Implement autofix
[ ] Implement suggestions

**How will the change be implemented (place an "X" next to just one item)?**

[ ] A new option
[ ] A new default behavior
[ ] Other

**Please provide some example code that this change will affect:**

```js
<!-- example code here -->
```

**What does the rule currently do for this code?**

**What will the rule do after it's changed?**
