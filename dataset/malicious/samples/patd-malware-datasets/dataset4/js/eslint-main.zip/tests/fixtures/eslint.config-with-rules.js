module.exports = [{
    rules: {
        quotes: ["error", "single"]
    }
}];
