module.exports = {
    rules: {
        quotes: [1, "single"]
    }
};
