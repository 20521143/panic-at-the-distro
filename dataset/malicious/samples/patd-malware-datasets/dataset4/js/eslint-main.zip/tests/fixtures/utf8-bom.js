﻿"use strict";

console.log("This file has [0xEF, 0xBB, 0xBF] as BOM.");
