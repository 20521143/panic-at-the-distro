module.exports = {
    parser: "espree",
    rules: {
        semi: [2, "always"]
    }
}
