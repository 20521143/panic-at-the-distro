
/*eslint-env node*/

console.log('bar');
