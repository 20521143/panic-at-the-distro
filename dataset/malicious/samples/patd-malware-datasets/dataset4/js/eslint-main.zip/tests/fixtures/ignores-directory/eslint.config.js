module.exports = {
    ignores: ["subdir/subsubdir"]
};
