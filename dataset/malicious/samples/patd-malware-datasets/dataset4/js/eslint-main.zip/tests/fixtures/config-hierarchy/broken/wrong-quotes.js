// function is necessary to avoid any other errors
function foo(bar) {
    "use strict";
    return bar;
}

foo('bar');
