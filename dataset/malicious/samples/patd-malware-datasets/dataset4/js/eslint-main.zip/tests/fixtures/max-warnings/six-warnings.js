var one = "One!";
var two = "Two!";
var three = "Three!";
var four = "Four!";
var five = "Five!";
var six = "Six!";
