module.exports = {
    parser: "./not-a-config.js",
    rules: {
        semi: [2, "always"]
    }
};
