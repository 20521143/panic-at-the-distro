var msg = 'hi'
if (msg == 'hi') {

}
