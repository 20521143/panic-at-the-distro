/* eslint no-else-return: "error" */
/* eslint no-useless-return: "error" */
/* eslint no-trailing-spaces: "error" */
function f() {
    if (true) {

    } else {
        return 1;
    }
}
