module.exports = {
    rules: {
        "no-undef": "warn"
    }
};
