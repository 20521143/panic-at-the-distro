module.exports = [
    {
        ignores: ["src/dist"]
    },
    {
        rules: {
            semi: "error"
        }
    }
];
