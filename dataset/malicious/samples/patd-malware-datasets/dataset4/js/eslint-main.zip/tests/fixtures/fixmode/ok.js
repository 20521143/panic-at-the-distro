var msg = "hi";
