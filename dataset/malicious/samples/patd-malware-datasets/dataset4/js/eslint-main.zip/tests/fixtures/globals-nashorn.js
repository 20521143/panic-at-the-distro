var path = __DIR__;
print(path);
load('something.js');
loadWithNewGlobal('other.js');
