var a = 42;
