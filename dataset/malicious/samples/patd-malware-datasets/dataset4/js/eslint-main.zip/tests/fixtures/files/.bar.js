var bar = "<div>Hello world!</div>";
bar(bar);
