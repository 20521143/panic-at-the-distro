var msg = 'hi' + foo;
