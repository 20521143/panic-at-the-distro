var foo = "<div>Hello world!</div>";
foo(foo);
