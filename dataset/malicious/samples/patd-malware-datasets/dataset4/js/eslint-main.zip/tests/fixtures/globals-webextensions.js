chrome.browserAction.setBadgeText({text: 'ᕕ( ᐛ)ᕗ'});
opr.sidebarAction.setTitle({title: 'ᕕ( ᐛ)ᕗ'});
browser.tabs.hide();
