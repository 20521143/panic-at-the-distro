var myDivElement = <div className="foo" />;
