var str = 'quotes';
