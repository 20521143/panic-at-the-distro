module.exports = { rules: { "no-console": "warn" } };
