module.exports = {
    parserOptions: {
      ecmaVersion: 2020,
    },
    'root': true,
    'rules': {
      'semi': 'error',
    },
  };
