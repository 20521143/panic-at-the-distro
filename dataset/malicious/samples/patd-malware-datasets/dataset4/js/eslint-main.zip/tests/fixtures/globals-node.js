var foo = __dirname;
console.log(foo);
