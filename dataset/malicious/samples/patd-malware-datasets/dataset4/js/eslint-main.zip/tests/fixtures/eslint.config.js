
module.exports = {
    rules: {
        strict: 0
    }
};
