module.exports = {
    rules: {
        semi: [1, "never"]
    }
};
