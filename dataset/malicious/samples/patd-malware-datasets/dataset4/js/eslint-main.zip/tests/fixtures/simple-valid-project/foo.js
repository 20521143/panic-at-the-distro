var a = 'b';
