var bar = baz;
bat = bar;
