module.exports = [
    {
        files: ["*.js"]
    },
    {
        ignores: ["eslint.config.js"]
    }
];
