/* eslint semi: ["error", "never"] */
/* eslint no-extra-semi: "error" */
var foo = function(){}
;[1].map(foo)
