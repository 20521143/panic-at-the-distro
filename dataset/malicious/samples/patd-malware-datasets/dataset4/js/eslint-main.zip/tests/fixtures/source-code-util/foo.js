var foo = 123;
