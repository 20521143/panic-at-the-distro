var bar = "string";
