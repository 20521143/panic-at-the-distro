module.exports = {
    rules: {
        quotes: 0;
    }
};
