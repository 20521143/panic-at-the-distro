var abc = 3;

console.log(abc);
