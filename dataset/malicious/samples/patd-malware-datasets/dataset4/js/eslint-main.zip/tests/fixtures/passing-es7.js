var foo = "bar";
if (foo) {
    foo = 3 ** 4;
}
