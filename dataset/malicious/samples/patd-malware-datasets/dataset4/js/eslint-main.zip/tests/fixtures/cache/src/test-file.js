var abc = 2;

console.log(abc);
