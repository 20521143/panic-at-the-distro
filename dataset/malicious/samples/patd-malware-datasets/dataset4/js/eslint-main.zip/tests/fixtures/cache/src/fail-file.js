var abc = 'some value'
console.log(foo);
