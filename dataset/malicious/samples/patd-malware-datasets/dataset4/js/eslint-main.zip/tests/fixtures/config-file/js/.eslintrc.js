module.exports = {
    extends: "eslint:recommended",
    rules: {
        semi: [2, "always"]
    }
};
