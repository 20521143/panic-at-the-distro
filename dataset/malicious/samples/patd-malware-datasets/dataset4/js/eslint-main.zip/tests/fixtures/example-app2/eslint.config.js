module.exports = [{
    files: ["subdir*/**/*.js"]
}];
