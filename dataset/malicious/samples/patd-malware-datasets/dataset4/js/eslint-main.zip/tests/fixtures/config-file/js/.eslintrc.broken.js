module.exports = {
    rules: {
        semi: [2, "always"]
    }

