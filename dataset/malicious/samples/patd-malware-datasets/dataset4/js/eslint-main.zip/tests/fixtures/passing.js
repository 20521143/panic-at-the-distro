var foo = "bar";
if (foo) {
    foo = "bar2";
}
