window.alert("foo");
