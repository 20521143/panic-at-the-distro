module.exports = {
    parser: "foo",
    rules: {
        semi: [2, "always"]
    }
};
