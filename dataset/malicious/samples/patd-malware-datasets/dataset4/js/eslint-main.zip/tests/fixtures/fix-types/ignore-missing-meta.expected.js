/* eslint semi: "error" */
/* eslint test/no-program: "error" */
/* eslint prefer-arrow-callback: "error" */
"use strict";

func(function() {
    return true;
});
