module.exports = {
    ignores: ["subdir"]
};
