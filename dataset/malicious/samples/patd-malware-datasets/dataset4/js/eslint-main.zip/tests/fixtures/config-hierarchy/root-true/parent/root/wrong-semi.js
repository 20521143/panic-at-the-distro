var str = 'quotes'
