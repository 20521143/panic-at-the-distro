"use strict"

module.exports = {
    parse() {}
}
