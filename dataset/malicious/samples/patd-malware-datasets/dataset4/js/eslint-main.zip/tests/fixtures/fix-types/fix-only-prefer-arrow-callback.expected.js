/* eslint semi: "error" */
/* eslint prefer-arrow-callback: "error" */
"use strict";

func(() => {
    return true;
})
