/* eslint semi: "error" */
/* eslint prefer-arrow-callback: "error" */
"use strict";

func(function() {
    return true;
});
