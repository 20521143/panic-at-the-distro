export default {
    rules: {
        "no-undef": "error"
    }
};
