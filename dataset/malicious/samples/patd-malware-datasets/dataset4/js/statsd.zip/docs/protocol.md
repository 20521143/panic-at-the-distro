# The StatsD Protocol

Coming soon! Meanwhile, see https://github.com/b/statsd_spec
