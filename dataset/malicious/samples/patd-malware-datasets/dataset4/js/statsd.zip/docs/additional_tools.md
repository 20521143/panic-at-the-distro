# Additional Tools

The following are tools you might find useful when using, contributing, or testing StatsD.

* [statsd-tg](http://octo.it/statsd-tg) – StatsD traffic generator; generates dummy traffic for load testing (C).
