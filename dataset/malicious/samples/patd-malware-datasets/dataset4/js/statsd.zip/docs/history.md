# What is StatsD?

StatsD is a front-end proxy for the Graphite/Carbon metrics server,
originally written by Etsy's Erik Kastner. It is based on ideas from
Flickr and this post by Cal Henderson: Counting and Timing. The
server was written in Node, though there have been implementations
in other languages since then.
