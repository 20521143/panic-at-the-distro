export interface RestoreViewFailResponse {
    cancelled?: boolean
}
