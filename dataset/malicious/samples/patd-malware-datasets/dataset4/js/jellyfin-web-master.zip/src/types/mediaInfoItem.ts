export interface MiscInfo {
    text?: string | number;
    cssClass?: string;
}
