export enum AutoScroll {
    NoScroll = 0,
    Smooth = 1,
    Instant = 2
}
