export enum QueryKey {
    ConfigurationPages = 'ConfigurationPages',
    PackageInfo = 'PackageInfo',
    Plugins = 'Plugins'
}
