/**
 * Custom event types.
 */
export enum EventType {
    SET_TABS = 'SET_TABS',
    SHOW_VIDEO_OSD = 'SHOW_VIDEO_OSD'
}
