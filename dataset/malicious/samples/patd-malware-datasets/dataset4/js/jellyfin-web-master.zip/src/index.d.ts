declare module '*.png' {
   const value: any;
   export = value;
}
