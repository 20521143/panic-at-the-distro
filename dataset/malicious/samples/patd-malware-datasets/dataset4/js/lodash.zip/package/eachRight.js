module.exports = require('./forEachRight');
